DOZ UP Chrome Extension Icons
==============================

Generate PNG icons from icon.svg using any of these methods:

Method 1: Online Converter
- Go to https://svgtopng.com/ or https://cloudconvert.com/svg-to-png
- Upload icon.svg (in this folder)
- Generate at sizes: 16x16, 32x32, 48x48, 128x128
- Save as: icon-16.png, icon-32.png, icon-48.png, icon-128.png

Method 2: ImageMagick (if installed)
  magick convert -background none icon.svg -resize 16x16 icon-16.png
  magick convert -background none icon.svg -resize 32x32 icon-32.png
  magick convert -background none icon.svg -resize 48x48 icon-48.png
  magick convert -background none icon.svg -resize 128x128 icon-128.png

Method 3: Inkscape (if installed)
  inkscape icon.svg -w 16 -h 16 -o icon-16.png
  inkscape icon.svg -w 32 -h 32 -o icon-32.png
  inkscape icon.svg -w 48 -h 48 -o icon-48.png
  inkscape icon.svg -w 128 -h 128 -o icon-128.png

Brand Colors (DOZ UP Official):
- Primary Green: #00d26a to #06d6a0 (gradient)
- Arrow Green: #00a854 to #00ff88 (gradient)
- Design: White cloud with upload arrow on green background

This icon matches the brand identity across:
- Desktop app (Windows/Mac/Linux)
- Web app (doz.com)
- Android app
- Chrome extension
