// DOZ UP Chrome Extension - Popup Script

document.addEventListener('DOMContentLoaded', init);

async function init() {
  loadRecentUploads();
  setupEventListeners();
}

function setupEventListeners() {
  // Capture visible area
  document.getElementById('captureVisible').addEventListener('click', async () => {
    showStatus('Capturing...', 'info');

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      chrome.runtime.sendMessage({ type: 'CAPTURE_VISIBLE', tabId: tab.id });
      window.close();
    } catch (err) {
      showStatus('Capture failed: ' + err.message, 'error');
    }
  });

  // Capture selection
  document.getElementById('captureSelection').addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        window.postMessage({ type: 'DOZ_START_SELECTION' }, '*');
      }
    });

    window.close();
  });

  // Upload file
  document.getElementById('uploadFile').addEventListener('click', () => {
    document.getElementById('fileInput').click();
  });

  document.getElementById('fileInput').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    showStatus('Uploading...', 'info');

    try {
      const dataUrl = await fileToDataUrl(file);
      const response = await chrome.runtime.sendMessage({
        type: 'UPLOAD_SELECTION',
        dataUrl: dataUrl
      });

      if (response.success) {
        showStatus('Uploaded! Link copied.', 'success');
        loadRecentUploads();
      } else {
        showStatus('Upload failed', 'error');
      }
    } catch (err) {
      showStatus('Upload failed: ' + err.message, 'error');
    }
  });

  // View all uploads
  document.getElementById('viewAll').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://up.doz.com.im/cabinet.html' });
  });

  // Listen for capture complete
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'CAPTURE_COMPLETE') {
      showStatus('Captured! Link copied.', 'success');
      loadRecentUploads();
    }
  });
}

async function loadRecentUploads() {
  const { uploads } = await chrome.runtime.sendMessage({ type: 'GET_RECENT_UPLOADS' });
  const list = document.getElementById('uploadsList');

  if (!uploads || uploads.length === 0) {
    list.innerHTML = '<div class="empty">No recent uploads</div>';
    return;
  }

  list.innerHTML = uploads.slice(0, 5).map(upload => `
    <div class="upload-item" data-url="${upload.url}">
      <div class="upload-info">
        <div class="upload-url">${upload.url}</div>
        <div class="upload-time">${formatTime(upload.timestamp)}</div>
      </div>
      <div class="upload-actions">
        <button class="icon-btn copy-btn" title="Copy link">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
          </svg>
        </button>
        <button class="icon-btn open-btn" title="Open link">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
            <polyline points="15 3 21 3 21 9"/>
            <line x1="10" y1="14" x2="21" y2="3"/>
          </svg>
        </button>
      </div>
    </div>
  `).join('');

  // Add click handlers
  list.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const url = btn.closest('.upload-item').dataset.url;
      navigator.clipboard.writeText(url);
      showStatus('Link copied!', 'success');
    });
  });

  list.querySelectorAll('.open-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const url = btn.closest('.upload-item').dataset.url;
      chrome.tabs.create({ url });
    });
  });

  list.querySelectorAll('.upload-item').forEach(item => {
    item.addEventListener('click', () => {
      navigator.clipboard.writeText(item.dataset.url);
      showStatus('Link copied!', 'success');
    });
  });
}

function formatTime(timestamp) {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = 'status ' + type;

  if (type !== 'info') {
    setTimeout(() => {
      status.className = 'status';
    }, 3000);
  }
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
