// DOZ UP Chrome Extension - Service Worker
// Background script for screenshot capture and upload

const API_HOST = 'up.doz.com.im';
const ENDPOINTS = {
  upload: '/upload',
  uploadFast: '/api/upload-fast',
  reserveUrl: '/api/reserve-url'
};

// ============ INITIALIZATION ============
chrome.runtime.onInstalled.addListener(() => {
  console.log('DOZ UP Extension installed');

  // Create context menus
  chrome.contextMenus.create({
    id: 'doz-capture-visible',
    title: 'Capture Visible Area',
    contexts: ['page']
  });

  chrome.contextMenus.create({
    id: 'doz-capture-selection',
    title: 'Capture Selection',
    contexts: ['page']
  });

  chrome.contextMenus.create({
    id: 'doz-upload-image',
    title: 'Upload to DOZ UP',
    contexts: ['image']
  });

  // Initialize device ID
  initDeviceId();
});

// ============ DEVICE ID ============
async function initDeviceId() {
  const { deviceId } = await chrome.storage.local.get('deviceId');
  if (!deviceId) {
    const newId = 'ext-' + crypto.randomUUID().replace(/-/g, '').slice(0, 32);
    await chrome.storage.local.set({ deviceId: newId });
  }
}

async function getDeviceId() {
  const { deviceId } = await chrome.storage.local.get('deviceId');
  return deviceId || 'ext-unknown';
}

// ============ KEYBOARD SHORTCUTS ============
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  if (command === 'capture-visible') {
    captureVisibleArea(tab.id);
  } else if (command === 'capture-selection') {
    startSelectionCapture(tab.id);
  }
});

// ============ CONTEXT MENU ============
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  switch (info.menuItemId) {
    case 'doz-capture-visible':
      captureVisibleArea(tab.id);
      break;
    case 'doz-capture-selection':
      startSelectionCapture(tab.id);
      break;
    case 'doz-upload-image':
      uploadExternalImage(info.srcUrl, tab.id);
      break;
  }
});

// ============ CAPTURE FUNCTIONS ============
async function captureVisibleArea(tabId) {
  try {
    // Capture the visible tab
    const dataUrl = await chrome.tabs.captureVisibleTab(null, {
      format: 'png',
      quality: 100
    });

    // Upload and get URL
    const url = await uploadDataUrl(dataUrl);

    if (url) {
      // Copy to clipboard
      await copyToClipboard(url);

      // Show notification
      showNotification('Screenshot Captured!', `Link copied: ${url}`);

      // Send to popup if open
      chrome.runtime.sendMessage({
        type: 'CAPTURE_COMPLETE',
        url: url
      }).catch(() => {});
    }
  } catch (error) {
    console.error('Capture failed:', error);
    showNotification('Capture Failed', error.message);
  }
}

async function startSelectionCapture(tabId) {
  // Inject selection overlay into the page
  await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      window.postMessage({ type: 'DOZ_START_SELECTION' }, '*');
    }
  });
}

async function uploadExternalImage(imageUrl, tabId) {
  try {
    // Fetch the image
    const response = await fetch(imageUrl);
    const blob = await response.blob();

    // Upload
    const url = await uploadBlob(blob);

    if (url) {
      await copyToClipboard(url);
      showNotification('Image Uploaded!', `Link copied: ${url}`);
    }
  } catch (error) {
    console.error('Upload failed:', error);
    showNotification('Upload Failed', error.message);
  }
}

// ============ UPLOAD FUNCTIONS ============
async function uploadDataUrl(dataUrl) {
  // Convert data URL to blob
  const response = await fetch(dataUrl);
  const blob = await response.blob();
  return uploadBlob(blob);
}

async function uploadBlob(blob) {
  const deviceId = await getDeviceId();

  const formData = new FormData();
  formData.append('image', blob, `screenshot-${Date.now()}.png`);
  formData.append('deviceId', deviceId);

  const response = await fetch(`https://${API_HOST}${ENDPOINTS.upload}`, {
    method: 'POST',
    headers: {
      'X-Device-ID': deviceId
    },
    body: formData
  });

  const result = await response.json();

  if (result.success && result.url) {
    // Save to recent uploads
    await saveRecentUpload(result.url, result.id);
    return result.url;
  }

  throw new Error(result.error || 'Upload failed');
}

// ============ STORAGE ============
async function saveRecentUpload(url, id) {
  const { recentUploads = [] } = await chrome.storage.local.get('recentUploads');

  recentUploads.unshift({
    url,
    id,
    timestamp: Date.now()
  });

  // Keep only last 50
  if (recentUploads.length > 50) {
    recentUploads.pop();
  }

  await chrome.storage.local.set({ recentUploads });
}

// ============ CLIPBOARD ============
async function copyToClipboard(text) {
  // Use offscreen document for clipboard access in MV3
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen/offscreen.html',
      reasons: ['CLIPBOARD'],
      justification: 'Copy URL to clipboard'
    });
  } catch (e) {
    // Document might already exist
  }

  await chrome.runtime.sendMessage({
    type: 'COPY_TO_CLIPBOARD',
    text: text
  });
}

// ============ NOTIFICATIONS ============
function showNotification(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'assets/icons/icon-128.png',
    title: title,
    message: message,
    priority: 2
  });
}

// ============ MESSAGE HANDLING ============
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CAPTURE_VISIBLE') {
    captureVisibleArea(sender.tab?.id).then(() => {
      sendResponse({ success: true });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true; // Keep channel open for async response
  }

  if (message.type === 'UPLOAD_SELECTION') {
    uploadDataUrl(message.dataUrl).then(url => {
      copyToClipboard(url);
      showNotification('Selection Captured!', `Link copied: ${url}`);
      sendResponse({ success: true, url });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }

  if (message.type === 'GET_RECENT_UPLOADS') {
    chrome.storage.local.get('recentUploads').then(({ recentUploads = [] }) => {
      sendResponse({ uploads: recentUploads });
    });
    return true;
  }
});
