// DOZ UP Chrome Extension - Content Script
// Handles selection capture overlay

(function() {
  let overlay = null;
  let selection = { startX: 0, startY: 0, endX: 0, endY: 0 };
  let isSelecting = false;

  // Listen for selection start message
  window.addEventListener('message', (event) => {
    if (event.data.type === 'DOZ_START_SELECTION') {
      startSelectionMode();
    }
  });

  function startSelectionMode() {
    // Create overlay
    overlay = document.createElement('div');
    overlay.id = 'doz-selection-overlay';
    overlay.innerHTML = `
      <div class="doz-selection-box" id="dozSelectionBox"></div>
      <div class="doz-selection-info" id="dozSelectionInfo">
        Click and drag to select area
      </div>
      <div class="doz-selection-actions" id="dozSelectionActions" style="display:none;">
        <button class="doz-btn doz-btn-capture" id="dozCapture">Capture</button>
        <button class="doz-btn doz-btn-cancel" id="dozCancel">Cancel</button>
      </div>
    `;
    document.body.appendChild(overlay);

    // Event listeners
    overlay.addEventListener('mousedown', startSelection);
    overlay.addEventListener('mousemove', updateSelection);
    overlay.addEventListener('mouseup', endSelection);

    document.getElementById('dozCapture').addEventListener('click', captureSelection);
    document.getElementById('dozCancel').addEventListener('click', cancelSelection);

    // ESC to cancel
    document.addEventListener('keydown', handleKeyDown);
  }

  function handleKeyDown(e) {
    if (e.key === 'Escape') {
      cancelSelection();
    } else if (e.key === 'Enter') {
      captureSelection();
    }
  }

  function startSelection(e) {
    if (e.target.closest('.doz-selection-actions')) return;

    isSelecting = true;
    selection.startX = e.clientX;
    selection.startY = e.clientY;

    const box = document.getElementById('dozSelectionBox');
    box.style.left = e.clientX + 'px';
    box.style.top = e.clientY + 'px';
    box.style.width = '0';
    box.style.height = '0';
    box.style.display = 'block';

    document.getElementById('dozSelectionInfo').style.display = 'none';
    document.getElementById('dozSelectionActions').style.display = 'none';
  }

  function updateSelection(e) {
    if (!isSelecting) return;

    selection.endX = e.clientX;
    selection.endY = e.clientY;

    const box = document.getElementById('dozSelectionBox');
    const left = Math.min(selection.startX, selection.endX);
    const top = Math.min(selection.startY, selection.endY);
    const width = Math.abs(selection.endX - selection.startX);
    const height = Math.abs(selection.endY - selection.startY);

    box.style.left = left + 'px';
    box.style.top = top + 'px';
    box.style.width = width + 'px';
    box.style.height = height + 'px';
  }

  function endSelection(e) {
    if (!isSelecting) return;
    isSelecting = false;

    const width = Math.abs(selection.endX - selection.startX);
    const height = Math.abs(selection.endY - selection.startY);

    if (width > 10 && height > 10) {
      // Show actions
      const actions = document.getElementById('dozSelectionActions');
      actions.style.display = 'flex';
      actions.style.left = Math.min(selection.startX, selection.endX) + 'px';
      actions.style.top = (Math.max(selection.startY, selection.endY) + 10) + 'px';
    }
  }

  async function captureSelection() {
    const left = Math.min(selection.startX, selection.endX);
    const top = Math.min(selection.startY, selection.endY);
    const width = Math.abs(selection.endX - selection.startX);
    const height = Math.abs(selection.endY - selection.startY);

    // Hide overlay before capture
    overlay.style.display = 'none';

    // Small delay to ensure overlay is hidden
    await new Promise(r => setTimeout(r, 50));

    // Request full page capture from background
    chrome.runtime.sendMessage({ type: 'CAPTURE_VISIBLE' }, async (response) => {
      // Crop the captured image
      const img = new Image();
      img.onload = async () => {
        // Account for device pixel ratio
        const dpr = window.devicePixelRatio || 1;

        const canvas = document.createElement('canvas');
        canvas.width = width * dpr;
        canvas.height = height * dpr;

        const ctx = canvas.getContext('2d');
        ctx.drawImage(
          img,
          left * dpr, top * dpr, width * dpr, height * dpr,
          0, 0, width * dpr, height * dpr
        );

        const dataUrl = canvas.toDataURL('image/png');

        // Upload the cropped image
        chrome.runtime.sendMessage({
          type: 'UPLOAD_SELECTION',
          dataUrl: dataUrl
        });

        cleanup();
      };

      // Get the captured image
      const capturedDataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
      img.src = capturedDataUrl;
    });
  }

  function cancelSelection() {
    cleanup();
  }

  function cleanup() {
    document.removeEventListener('keydown', handleKeyDown);
    if (overlay) {
      overlay.remove();
      overlay = null;
    }
    selection = { startX: 0, startY: 0, endX: 0, endY: 0 };
    isSelecting = false;
  }
})();
