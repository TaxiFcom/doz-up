// DOZ UP Chrome Extension - Offscreen Document
// Handles clipboard operations for Manifest V3

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'COPY_TO_CLIPBOARD') {
    copyToClipboard(message.text);
  }
});

async function copyToClipboard(text) {
  try {
    // Try navigator.clipboard first
    await navigator.clipboard.writeText(text);
  } catch (err) {
    // Fallback to textarea method
    const textarea = document.getElementById('clipboard');
    textarea.value = text;
    textarea.select();
    document.execCommand('copy');
  }
}
